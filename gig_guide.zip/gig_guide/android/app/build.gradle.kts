// android/app/build.gradle.kts  (Module-level)

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}

flutter {
    source = "../.."
}

android {
    // Use your actual namespace/package if different
    namespace = "com.example.gig_guide"

    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    defaultConfig {
        // Use your actual applicationId if different
        applicationId = "com.example.gig_guide"

        minSdk = flutter.minSdkVersion   // usually 21+
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    // ✅ Java 17 + Core library desugaring (required by flutter_local_notifications)
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            // When you’re ready to shrink/obfuscate, set true and add proguard rules.
            isMinifyEnabled = false
            isShrinkResources = false
            // proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            // Explicitly disable resource shrinking in debug
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

dependencies {
    // Needed when isCoreLibraryDesugaringEnabled = true
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // If minSdk < 21 and you hit multidex issues later:
    // implementation("androidx.multidex:multidex:2.0.1")
}
