// android/build.gradle.kts  (PROJECT-LEVEL FILE)
// No plugins{} block here. Repositories + (optional) build dir relocation + clean task.

allprojects {
    repositories {
        google()
        mavenCentral()
        // (optional) gradlePluginPortal() if you ever need it
        // gradlePluginPortal()
    }
}

// (Your project had custom build dir relocation — keep it)
val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)

    // Ensure repos also available to subprojects
    repositories {
        google()
        mavenCentral()
    }

    // Keep this – Flutter expects :app to be configured early
    project.evaluationDependsOn(":app")
}

// Clean task
tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
