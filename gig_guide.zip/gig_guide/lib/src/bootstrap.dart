import 'package:flutter/material.dart';
import 'app/app.dart';
import 'services/notification_service.dart';

Future<void> bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init(); // local notifications
  runApp(const App());
}
