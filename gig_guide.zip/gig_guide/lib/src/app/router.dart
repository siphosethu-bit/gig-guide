import 'package:go_router/go_router.dart';

// NOTE: router.dart is in lib/src/app, so we go up TWO levels to reach lib/features
import '../../features/events/presentation/events_home_screen.dart';
import '../../features/events/presentation/event_details_screen.dart';

GoRouter buildRouter() => GoRouter(
      initialLocation: '/',
      routes: [
        GoRoute(
          path: '/',
          builder: (_, __) => const EventsHomeScreen(),
          routes: [
            GoRoute(
              path: 'event/:id',
              builder: (_, state) => EventDetailsScreen(
                id: state.pathParameters['id']!,
              ),
            ),
          ],
        ),
      ],
    );
