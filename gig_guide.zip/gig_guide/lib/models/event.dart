class Event {
  final String id;
  final String name;
  final String venue;
  final String imageUrl;
  final DateTime start;
  final double? price; // null = Free
  final double lat;
  final double lng;

  const Event({
    required this.id,
    required this.name,
    required this.venue,
    required this.imageUrl,
    required this.start,
    required this.lat,
    required this.lng,
    this.price,
  });
}
