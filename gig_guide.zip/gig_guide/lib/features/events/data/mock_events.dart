import 'package:intl/intl.dart';
import '../../../models/event.dart';

final List<Event> mockEvents = [
  Event(
    id: '1',
    name: 'Afro Sundaze',
    venue: 'Zone 6 Venue • Soweto',
    imageUrl:
        'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=1200&auto=format&fit=crop',
    start: DateTime.now().add(const Duration(days: 2, hours: 18)),
    price: 120,
    lat: -26.2458,
    lng: 27.8856,
  ),
  Event(
    id: '2',
    name: 'Deep House Fridays',
    venue: 'Great Dane • Braam',
    imageUrl:
        'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=1200&auto=format&fit=crop',
    start: DateTime.now().add(const Duration(days: 5, hours: 20)),
    price: 150,
    lat: -26.1952,
    lng: 28.0340,
  ),
  Event(
    id: '3',
    name: 'Sunset Lounge',
    venue: 'Soweto Theatre',
    imageUrl:
        'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=1200&auto=format&fit=crop',
    start: DateTime.now().add(const Duration(days: 8, hours: 17)),
    price: null, // Free
    lat: -26.2467,
    lng: 27.8870,
  ),
];

String formatDateTime(DateTime dt) =>
    DateFormat('EEE, MMM d • h:mm a').format(dt);
