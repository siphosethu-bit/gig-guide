import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../events/data/mock_events.dart';

class EventsHomeScreen extends StatelessWidget {
  const EventsHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SA Gig Guide')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: mockEvents.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) {
          final e = mockEvents[i];
          return InkWell(
            onTap: () => context.go('/event/${e.id}'),
            borderRadius: BorderRadius.circular(16),
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: CachedNetworkImage(
                      imageUrl: e.imageUrl,
                      fit: BoxFit.cover,
                    ),
                  ),
                  ListTile(
                    title: Text(e.name),
                    subtitle: Text('${e.venue} • ${formatDateTime(e.start)}'),
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(999),
                        color: Theme.of(context).colorScheme.secondaryContainer,
                      ),
                      child: Text(
                        e.price == null ? 'Free' : 'R${e.price!.round()}',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
