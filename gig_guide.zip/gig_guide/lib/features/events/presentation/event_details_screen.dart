import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../data/mock_events.dart';
// This file is in lib/features/events/presentation
// We need to reach lib/src/services/notification_service.dart
import '../../../src/services/notification_service.dart';

class EventDetailsScreen extends StatelessWidget {
  final String id;
  const EventDetailsScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final e = mockEvents.firstWhere((x) => x.id == id);

    Future<void> openUber() async {
      final uri = Uri.parse(
        'https://m.uber.com/ul/?action=setPickup'
        '&dropoff[latitude]=${e.lat}&dropoff[longitude]=${e.lng}'
        '&dropoff[formatted_address]=${Uri.encodeComponent(e.venue)}',
      );
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    }

    Future<void> remind1hBefore() async {
      await NotificationService.instance.scheduleOneShot(
        id: int.parse(e.id),
        title: 'Event reminder',
        body: '${e.name} starts in 1 hour',
        when: e.start.subtract(const Duration(hours: 1)),
      );
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Reminder set for 1 hour before')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(e.name)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(e.venue, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(formatDateTime(e.start)),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: openUber,
              icon: const Icon(Icons.local_taxi),
              label: const Text('Get Uber to venue'),
            ),
            const SizedBox(height: 12),
            FilledButton.tonal(
              onPressed: remind1hBefore,
              child: const Text('Remind me 1 hour before'),
            ),
            const Spacer(),
            Text(
              'Ticket price: ${e.price == null ? 'Free' : 'R${e.price!.toStringAsFixed(0)}'}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}
